 <ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>
    <li class="treeview">
    <li><a href="<?php echo e(route('products')); ?>"><i class="fa fa-sticky-note-o"></i> <span>Продукты</span></a></li>
    <li><a href="<?php echo e(route('orders')); ?>"><i class="fa fa-sticky-note-o"></i> <span>Заказы</span></a></li>
    <li><a href="<?php echo e(route('users')); ?>"><i class="fa fa-sticky-note-o"></i> <span>Пользователи</span></a></li>
</ul>