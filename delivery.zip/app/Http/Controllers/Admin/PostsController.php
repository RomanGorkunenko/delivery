<?php
namespace App\Http\Controllers\Admin;
use Image;
use App\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Cart;
class PostsController extends Controller
{
    public function index() {
        $all = Products::paginate(5);
        return view('admin.posts.index', ['all'=>$all]);
    }
    
    public function users() {
        $all = Products::paginate(5);
        return view('admin.posts.users', ['all'=>$all]);
    }
    
    public function five() {
        $all = Products::all();
        $count = Cart::count();
        return view('welcome', ['all'=>$all, 'count'=>$count]);     
    }
    
    public function create(Request $request) {   
        $products= new Products();    
        if($request->method()=='POST'){
            $products->id = $request->id;
            $products->title = $request->title;
            $products->category = $request->category;
            $products->description = $request->description;
            $products->weight = $request->weight;
            $image = $request->file('image');
            $upload = './uploads';
            $filename = $image->getClientOriginalName();
            $img = Image::make($image)->resize(320, 240);
            $img->save($upload.'/'.$filename);
            $products->filename = $filename;
            $products->price = $request->price;
            $products->save();
            return redirect()->route('products');
        }
        return view('admin.posts.create');
    }
    
    public function edit($id, Request $request) {
        $productsClass = Products::find($id);  
        if($request->method()=='POST'){
            $productsClass->title = $request->title1;
            $productsClass->category = $request->category1;
            $productsClass->description = $request->description1;
            $productsClass->weight = $request->weight1; 
            $image1 = $request->file('images');
            $upload1 = './uploads';
            $filename1 = $image1->getClientOriginalName();
            $img1 = Image::make($image1)->resize(320, 240);
            $img1->save($upload1.'/'.$filename1);
            $productsClass->filename = $filename1;
            $productsClass->price = $request->price1;
            $productsClass->save();
            return redirect()->route('products');
        }
        return view('admin.posts.edit', ['id'=>$productsClass->id, 'title'=>$productsClass->title, 'category'=>$productsClass->category, 'description'=>$productsClass->description, 'weight'=>$productsClass->weight, 'filename'=>$productsClass->filename, 'price'=>$productsClass->price]);
    }
    
    public function destroy($id)
    {
        $products_Class = Products::find($id);
        $products_Class->delete();
        return redirect()->route('products');
    }
}